export const getCurrentYear = () => {
  return new Date().getFullYear();
};
